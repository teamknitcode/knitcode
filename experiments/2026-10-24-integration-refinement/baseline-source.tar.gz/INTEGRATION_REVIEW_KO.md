# KnitCode 3개 저장소 통합 평가 (재검토, 2026-10-23)

## 최신 판단 — 2026-10-24 통합 실험 반영

**이정연의 원본 분석·탐색 기능을 공통 실행 파이프라인에 연결했고, 전후 PyCG 비교 후 `integrated` + `supported`를 기본으로 선택했다.** 기존 모듈형 엔진에 원본 분석기를 함께 실행하는 어댑터 방식이다. 두 분석기를 하나의 해석 알고리즘으로 다시 작성한 것은 아니다.

- 앞서 누락으로 확인한 타입 컨테이너·진리값 검사·자식 메서드 후보·함수 참조·진입점·읽는 순서·계층·순환·동적 호출 정보를 복구했다. 원본 API·뷰어·결과도 보존한다.
- 기존 엔진의 호출 상태와 카운트는 유지한다. 추가 정보는 공통 ID의 `supplemental_edges`·탐색 필드로 제공하고, 원본 전체 결과는 `ljy_graph.json`·`ljy_report.html`로 출력한다.
- 전체 후보 합집합은 정밀도가 떨어져 기본값으로 채택하지 않았다. 넓은 다형성 후보는 조회용으로 보존하고, 기본 예측은 타입 근거가 있는 미해결 호출을 보강하는 정책을 사용한다.
- 공식 macro 주 평가에서 기존 4개 프로젝트 점수를 유지하고 fabric F1이 **70.8%→72.1%**로 개선됐다. Micro Complete/Sound는 기존과 같은 **111/68**이다. 암묵 호출 포함 보조 평가에서는 일부 정밀도 하락이 있어, 모든 지표가 개선됐다고 주장하지 않는다.
- 원본 회귀 검사를 저장소에 복원한 최종 결과는 **496 passed, 7 skipped, 27 subtests passed**다. 기존 데코레이터 검사 충돌은 기록 도구 검사와 실제 누락을 확인하는 정책 검사로 분리했다. 데코레이터 누락 자체는 남아 있다.
- 추가 분석·출력 때문에 처리 시간은 늘어난다. 기존 엔진만 쓰려면 `--analysis-profile baseline`을 선택할 수 있고, 정확한 시작 버전은 압축본으로 보존했다.

[별도 실험 로그](EXPERIMENT_LOG_KO.md), [전후 비교·선택 근거](experiments/2026-10-24-ljy-integration/REPORT_KO.md), [기준선 소스와 해시](experiments/2026-10-24-ljy-integration/baseline-manifest.json)를 참고한다.

**아래 1~6절은 2026-10-23 통합 전 재검토의 이력이다.** 당시의 미이식·실패 기록을 덮어 지우지 않고 보존했다. 현재 상태는 위 판단과 2026-10-24 실험 보고서를 기준으로 한다. 박재형 원본의 별도 평가 도구 API 교체 문제까지 이번에 모두 복구한 것은 아니다.

## 1. 비교 대상과 버전

| 역할 | 원본 | 확인한 버전·위치 |
|---|---|---|
| 기반 엔진: 정세은 | [정세은 저장소](https://github.com/GreatJung1/KnitCode) | `c7b63ab52313117fd9828cf80bec6a4bde7d2bea`. 루트 엔진·테스트와 10/22 개선 엔진인 `jse/`를 구분 |
| 박재형 결과 | [박재형 저장소](https://github.com/jbag6033-ai/knitcode) | `e0cef3d12d31411c71925b556d5715b352ba8291` |
| 이정연 독립 원본 | [이정연 저장소의 main](https://github.com/Lee-jeongyeon/KnitCode/tree/main) | `d3a9da6`, 단일 파일 `analyze_project.py` 기반 v2.3 |
| 검사할 3자 통합본 | [이정연 저장소의 merge](https://github.com/Lee-jeongyeon/KnitCode/tree/merge) | `5e92661`, 현재 작업 폴더 |

박재형 원본 저장소 주소는 통합본 README에서 박재형의 변경 사항을 설명하는 항목에 명시된 링크를 따라 선택했다. 현재 폴더는 박재형의 독립 원본 자체가 아니라 이정연 저장소의 `merge` 브랜치다. 같은 저장소의 `main`과 `merge`를 같은 결과물로 취급하지 않았다.

통합 이력은 `700a11a`(정세은 v2.5 기준선 도입) → `8f72761`(정세은의 최신 `jse/` 위에 이정연 변경 이식) → `5e92661`(박재형 변경 통합)로 확인했다. 파일을 전부 보존한 합본이 아니라, 기반 엔진에 기능을 선택적으로 옮긴 형태다.

환경은 macOS, Python 3.12, pytest 9.1.1이다. 검사 대상은 위 커밋에 지난 검토의 None 이름 방어 수정과 평가 도구 추가가 들어간 현재 작업 트리다. 이번 재검토에서는 제품 엔진을 추가로 수정하지 않았다.

## 2. 원본 테스트를 이용한 보존 검사

각 원본은 별도 폴더에서 먼저 실행했다. 통합 엔진 검사에는 현재 통합본의 런타임 파일과 원본 `tests/`를 임시 폴더에 복사했다. 서로 다른 저장소의 동명 모듈이 섞이지 않도록 별도 Python 프로세스에서 실행했다.

| 검사 | 결과 | 해석 |
|---|---|---|
| 정세은 루트 원본 엔진 + 원본 테스트 | **265 통과**, subtest 2 통과 | 기준선 정상 |
| 정세은 최신 `jse/` 엔진 + 공개된 원본 테스트 | **265 통과**, subtest 2 통과 | 최신 엔진에서도 공개 회귀 검사 유지 |
| 현재 통합 런타임 + 정세은 원본 테스트 | **265 통과**, subtest 2 통과 | 기반 엔진의 공개된 동작 계약 보존 |
| 박재형 원본 엔진 + 원본 테스트 | **403 통과**, subtest 24 통과 | 기준선 정상 |
| 현재 통합 런타임 + 박재형 원본 테스트 전체 | **수집 오류 2건** | 원본 평가 도구 모듈이 통합본에 없음 |
| 위 평가 도구 테스트 파일 2개를 제외한 박재형 원본 테스트 | **392 통과 / 6 실패**, subtest 24 통과 | 아래 형식·구현 변경을 대조해야 함 |
| 간선 형식·외부 계약 mock 대상만 맞춘 동일 런타임 테스트 | **398 통과**, subtest 24 통과 | 6건에서 실제 기능 손실은 재현되지 않음 |
| 이정연 `main` 원본 자체 테스트 | **59 통과 / 7 skip** | 외부 프로젝트 기준선 6개·선택적 브라우저 검사 1개 제외 |
| 현재 통합본이 보유한 자체 테스트 | **163 통과 / 1 실패**, subtest 25 통과 | 실행 추적·데코레이터 정책 불일치 잔존 |

주의 사항:

- 정세은의 `jse/` 보고서는 305개 통과를 기록하지만, 확인한 공개 `jse/` 디렉터리에는 그 최신 테스트 파일들이 없다. 이번에 실제 실행해 증명한 범위는 공개된 루트 테스트 265개와 별도 기능 재현 예제다. 문서의 305개 전체를 재검증했다고 주장하지 않는다.
- 박재형의 403개에는 기반 엔진 테스트가 포함된다. 정세은의 265개와 합쳐 “668개 독립 테스트”로 세면 안 된다.
- 이정연 원본 테스트는 옛 `analyze_project` API·JSON 형식에 의존한다. 이 테스트 전체가 현재 통합본에서 통과했다고 주장하지 않는다. 대신 아래 동일 입력 비교로 이식 여부를 확인했다.
- 박재형 원본의 평가 도구를 보조 파일로 남겨 둔 확장 검사에서도 형식 조정 후 403개가 통과했다. 그러나 이는 원본 평가 도구가 통합본에 포함됐다는 뜻이 아니므로, 주 판단은 통합 런타임만 사용한 398개 결과를 따른다.

### 박재형 원본 테스트 실패 6건의 원인

1. **콜백 검사 3건:** 원본은 `edges`의 `callback_call_id`로 찾는다. 통합본은 `implicit_edges`의 `CALLS_IMPLICIT`에 보관하고 `trigger_call_id`로 실제 `sorted()` 호출을 참조한다. 이를 읽도록 바꾸면 이름 있는 콜백·람다 콜백·같은 콜백의 두 호출 지점이 모두 유지된다.
2. **property 검사 2건:** 원본은 getter 실행을 `edges/CALLS`에서 찾는다. 통합본에서는 `implicit_edges`로 옮겨졌다. 명시적 호출과 암묵 호출을 함께 검사하면 getter 접근과 상속 getter의 자식 수신 객체 추적이 유지된다.
3. **외부 상속 계약 검사 1건:** 원본은 `stdlib_mro.multiprocessing_contract`를 mock한다. 통합본은 `external_bases.ExternalClassIndex`로 구현을 교체했으므로 원래 mock은 아무 효과가 없다. 새 구현의 계약을 알 수 없게 mock하면 기존처럼 미확정으로 남는다.

기대 호출 대상이나 예제 소스를 완화하지 않았다. 조정한 내용은 [테스트 변경 대조 파일](reports/three-way-integration-2026-10-23/test_external_mro_callbacks.py.diff.txt)과 [property 검사 대조 파일](reports/three-way-integration-2026-10-23/test_fabric_properties.py.diff.txt)에 남겼다.

## 3. 팀원별 기능 보존 결과

### 정세은: 기반 엔진과 최신 보강

- AST·심볼·객체 흐름·C3 MRO·호출 상태 분류: 원본 테스트 265개가 통합 런타임에서 통과했다.
- 최신 `jse/class_decorators.py`, `jse/override_relations.py`는 현재 통합본과 파일 내용이 동일하다. `OVERRIDDEN_BY` 구조 관계와 클래스 데코레이터 정책은 코드 수준에서 보존됐다.
- `with ... as`가 반환한 다른 클래스 객체를 추적하는 동일 입력에서도 최신 JSE와 통합본은 모두 해당 객체의 메서드를 연결했다.
- 다만 최신 JSE 보고서의 305개 전체 테스트는 공개 소스만으로 재실행할 수 없어 검증 범위를 제한한다.

### 박재형: 분석 보강·외부 호출·VS Code

- 기본 인자 factory, property 반환값, 이름 범위, 메서드 바꿔치기 시 보수적 판단, 콜백, 외부 호출·상속 검사는 형식·mock 대상을 맞춘 원본 런타임 테스트 398개에서 보존을 확인했다.
- `vscode-extension/extension.js`, `package.json`, CSS, `vscode_history.py`, `scripts/package_extension.py`, `scripts/analyze_project.py`는 원본과 동일하다. 웹뷰 `map.js`와 `vscode_export.py`는 통합에 맞춰 변경됐다.
- VSIX 압축 해제 후 번들 엔진 실행과 웹뷰 동작 검사는 현재 통합본 자체 테스트에서 통과한다.
- `stdlib_mro.py`는 그대로 복사되지 않고 `external_bases.py`로 대체됐다. 따라서 파일 부재만으로 기능 누락으로 판단하지 않는다.
- **평가 도구의 원본 API/CLI는 보존되지 않았다.** `scripts/evaluate_paper.py`, `scripts/compare_paper_runs.py`, 원본의 일부 참조 자료가 없다. `pycg_benchmark.py`가 macro 평가를 맡고 있지만, 기존 도구를 사용하는 호출과 테스트는 그대로 실행되지 않는다. 기능을 대체했다면 명령 대응표와 비교 도구의 대체 범위를 명시할 필요가 있다.

### 이정연: 일부 이식, 일부 미이식 확인

외부 호출 분류, 연산자 암묵 호출, context manager, 실행 추적·뷰어 등은 통합됐다. 그러나 독립 원본에 있던 모든 분석·탐색 정보를 보존한 상태는 아니다.

| 동일 입력으로 검사한 기능 | 이정연 `main` 원본 | 현재 통합본 | 판단 |
|---|---|---|---|
| 직접 함수 호출·C3 다중 상속 | 기대 호출 연결 | 기대 호출 연결 | 보존 |
| 반환 타입힌트 기반 factory 결과의 메서드 | 연결 | 연결 | 보존 |
| `item + item` → `__add__` 암묵 호출 | 연결 | `CALLS_IMPLICIT` 연결 | 이식 확인 |
| `with Box() as item`의 반환 객체 메서드 | 연결 | 연결 | 이식 확인 |
| `flag: Flag`의 `if flag` → `Flag.__bool__` | 연결 | 해당 호출 없음 | **미이식/행동 차이** |
| `Box.items: list[Item]` 반복 원소의 `Item.run` | 연결 | 해당 호출 없음 | **미이식/행동 차이** |
| `obj: Base` 호출의 `Child.run` 다형성 후보 | `calls_override`로 연결 | `Base.run`만 연결 | **후보 연결 미보존** |
| `threading.Thread(target=work)` 함수 참조 | `references` 간선 | 해당 관계 없음 | **참조 관계 미보존** |
| 진입점·읽는 순서 | `entry_points`, `reading_order` 제공 | 해당 결과 없음 | **미이식** |
| import 순환·패키지 계층·동적 호출 표식 | `import_cycles`, `hierarchy`, `dynamic_calls` 제공 | 해당 결과 없음 | **원본 정보 미보존** |

위 “없음”은 결과 키 이름만 다른지 확인하는 데 그치지 않았다. 같은 입력의 호출 간선과 실제 반환 데이터를 대조했다. 예를 들어 두 모듈의 import 순환과 `__main__` 진입점, 변수 이름을 쓰는 `getattr(obj, name)` 표식은 원본에서 생성되지만 통합 결과에는 해당 정보가 없다.

`OVERRIDDEN_BY`가 있다는 사실로 `calls_override` 보존을 대신할 수 없다. 전자는 **부모 메서드 → 자식 메서드의 구조 관계**이고, 후자는 **호출자 → 실제 호출될 수 있는 자식 메서드 후보**다. 사용자에게 보여 주는 의미와 영향 범위 계산에서의 쓰임이 다르다.

이 차이들이 모두 의도치 않은 회귀라고 단정하지는 않는다. 기반 엔진 교체 시 정책적으로 제외했을 수 있다. 다만 “세 사람의 결과를 모두 통합했다”는 요구를 기준으로는 미이식 항목이며, 제외할 기능은 명시적으로 합의·문서화해야 한다.

동일 입력 14종과 메타데이터·외부 계약 검사 결과는 [프로브 결과와 실행 코드](reports/three-way-integration-2026-10-23/)에 저장했다. 이 작은 예제들은 기능 차이의 재현 근거이며 전체 정확도 통계로 해석하지 않는다.

## 4. 여전히 남은 통합 품질 문제

### 4.1 원본 회귀 테스트의 보존 공백

현재 `tests/`만 실행해서는 기반 엔진의 원본 테스트 265개 전체를 실행하지 않는다. 이번에 외부 원본 테스트를 복원해 통과를 확인했지만, 이 검사가 통합 저장소의 지속적인 회귀 검사로 유지되지는 않는다. 이정연의 옛 API 테스트·fixtures도 현재 구조로 이식돼 있지 않다.

따라서 통합본 자체 테스트가 통과하더라도 세 원본의 기능이 모두 유지됐다고 증명할 수 없다. 기반 테스트와 이정연의 기능별 기대 호출을 현행 구조에 맞춰 보존할 필요가 있다.

### 4.2 기존 실행 추적 테스트 실패

`TraceRecallTests.test_record_with_pytest`는 계속 실패한다. `test_cached → cached`를 놓쳐 관찰된 함수 간 호출 7개 중 6개를 맞추며 recall은 0.8571이다. 일반 데코레이터 함수를 보수적으로 연결하지 않는 현행 정책과 기대값 1.0이 맞지 않는다. 실행 추적 도구가 실행 자체를 못 하는 문제와는 구분한다.

### 4.3 CLI 중단 오류: 지난 검토에서 수정 완료

`external_calls.imported()`에서 constructed 이름이 None이면 `.partition()`이 실패하던 문제는 지난 검토에서 수정했다. 이름이 없으면 근거 없는 외부 후보에서 제외하고, 회귀 검사와 실제 JSON·HTML 생성까지 확인했다. 이번 재검토에서는 이 방어를 포함한 현재 엔진을 검사했다.

## 5. 후속 조치 우선순위

1. **통합 범위 확정:** 위 이정연 미이식 항목을 복구할지, 제품 범위에서 제외할지 결정한다. 현재 상태를 완전 통합으로 표기하지 않는다.
2. **세 원본의 회귀 검사 보존:** 정세은 265개, 박재형의 현행 스키마에 맞춘 추가 검사, 이정연의 타입·참조·다형성·탐색 정보 검사를 통합 저장소에서 재실행할 수 있게 만든다. 중복 테스트를 성과 수치로 합산하지 않는다.
3. **출력 계약 문서화:** `edges`/`implicit_edges`, `CALLS_IMPLICIT`, 콜백 trigger, 구조적 재정의와 호출 후보의 차이, 원본 CLI 대체 경로를 명확히 한다.
4. **실행 추적의 정책·기대값 정합성 해결:** 실패를 가리기 위해 기대값만 낮추거나 모든 데코레이터를 무조건 연결하지 않는다.
5. **그다음 PyCG 성능 개선:** 반환 함수·클로저·데코레이터·컨테이너·제너레이터의 누락을 고친다. 원본 기능 보존을 먼저 검증한 뒤 같은 기준선으로 비교한다.

## 6. 산출물과 재현 근거

- [audit-evidence.json](reports/three-way-integration-2026-10-23/audit-evidence.json): 원본 커밋, 파일 SHA-256·동일/변경/부재 목록, 테스트 결과.
- [probes-integrated.json](reports/three-way-integration-2026-10-23/probes-integrated.json), [probes-ljy-main.json](reports/three-way-integration-2026-10-23/probes-ljy-main.json), [probes-greatjung-jse.json](reports/three-way-integration-2026-10-23/probes-greatjung-jse.json), [probes-jeff.json](reports/three-way-integration-2026-10-23/probes-jeff.json): 같은 소스에 대한 실제 호출·참조 간선과 결과 필드.
- [probe_runner.py](reports/three-way-integration-2026-10-23/probe_runner.py): 입력 소스를 포함한 독립 실행 코드. 분석 대상 소스는 실행하지 않는다.
- 같은 디렉터리의 `*.txt`: 테스트 원문 로그와 스키마 조정 대조.
- [PyCG 비교 보고서](reports/pycg-2026-10-23/REPORT_KO.md): 공식 5개 프로젝트·112개 예제의 기존 평가. 이번에는 그 평가를 새로 실행하지 않았으며, 여기서 발견한 기능 보존 공백과 구분한다.

프로브 재실행 예시:

```bash
python3 -I reports/three-way-integration-2026-10-23/probe_runner.py \
  --engine-root . --kind modular --output /tmp/knitcode-integration-probes.json
python3 -I reports/three-way-integration-2026-10-23/probe_runner.py \
  --engine-root benchmarks/three-way-review/ljy-main --kind ljy \
  --output /tmp/knitcode-ljy-probes.json
```

원본 복제본과 검사 스냅샷은 Git 제외 경로인 `benchmarks/`에만 만들었다. 제품 코드·원격 브랜치는 이번에 변경하지 않았고 푸시하지 않았다. 보고서와 검사 증거만 추가·갱신했다.
