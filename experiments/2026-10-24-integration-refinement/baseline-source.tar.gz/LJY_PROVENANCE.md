# 이정연 분석기 원본 보존

`analyze_project.py`, `knit_viewer.py`, `viewer_template.html`, `compare_pycg.py`는 Lee-jeongyeon/KnitCode의 main `d3a9da6`에서 변경 없이 가져왔다. 원본 API·JSON·오프라인 뷰어를 보존한다. 원본 `trace_recall.py`도 변경 없이 보존하되 현재 추적 도구와 충돌하지 않도록 파일 이름은 `ljy_trace_recall.py`로 정했다.

`tests/ljy_original`의 원본 테스트는 저장 위치에 맞춰 ROOT 경로를 조정하고 위 추적 도구의 import·CLI 경로만 새 이름으로 변경했다. 호출 정답은 변경하지 않았다. `tests/jse_original`은 정세은 기반 원본 테스트를 보존하며, 재배치된 CLI 경로와 fixture 수집 제외만 조정했다.

새 통합 어댑터는 `ljy_integration.py`다. 기존 모듈형 엔진의 호출 상태와 이정연의 보충 후보를 구분한다. 기본 `supported` 정책은 기존 해석을 유지하고 타입 추적 근거가 있는 미해결 호출만 예측에 추가한다. 전체 원본 결과·다형성 후보·참조·탐색 메타데이터는 별도로 유지한다.
