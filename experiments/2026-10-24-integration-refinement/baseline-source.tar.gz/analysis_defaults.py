"""Version selection is documented in experiments/2026-10-24-ljy-integration/."""
DEFAULT_PROFILE = 'integrated'
DEFAULT_CALL_POLICY = 'supported'
