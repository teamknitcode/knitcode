"""Bridge Lee Jeongyeon's analyzer to the shared graph without changing call-site accounting.

The primary engine keeps its explicit-call status contract. Additional static
candidates, references and navigation data carry their producer and namespace.
Only the scanned source snapshot is analyzed; no target code is imported.
"""
from collections import Counter, defaultdict
from pathlib import Path, PurePosixPath
import tempfile

from symbol_builder import module_name_from_file


def augment_graph(graph, symbols, resolver, *, call_policy):
    import analyze_project as ljy

    sources = symbols.get('analysis_sources') or {}
    repository = symbols.get('repository') or 'project'
    with tempfile.TemporaryDirectory(prefix='knitcode-ljy-') as tmp:
        root = Path(tmp) / 'project'
        root.mkdir()
        for file, source in sources.items():
            rel = PurePosixPath(file)
            if rel.parts and rel.parts[0] == repository:
                rel = PurePosixPath(*rel.parts[1:])
            if rel.is_absolute() or '..' in rel.parts:
                raise ValueError(f'Unsafe source snapshot path: {file}')
            path = root / rel
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(source, encoding='utf-8')
        _, native = ljy.analyze(root)

    nodes = {n['id']: n for n in graph['nodes']}
    native_nodes = {n['id']: n for n in native['nodes']}
    by_name = defaultdict(list)
    for n in graph['nodes']:
        by_name[(n['file'], n['canonical_name'], n['kind'])].append(n)
    mapped, extra_nodes = {}, []
    kinds = {'module': 'MODULE', 'class': 'CLASS', 'function': 'FUNCTION', 'method': 'METHOD'}
    for old_id, n in native_nodes.items():
        rel = n.get('file') or old_id.split('::')[0]
        file = repository + '/' + rel
        module = module_name_from_file(file, repository, symbols.get('source_roots') or ())
        _, sep, qual = old_id.partition('::')
        canonical = module + ('.' + qual if sep else '')
        kind = kinds[n['type']]
        candidates = by_name[(file, canonical, kind)]
        matched = [s for s in candidates if s.get('line') == n.get('line')]
        target = matched[0] if len(matched) == 1 else candidates[0] if len(candidates) == 1 else None
        if target:
            mapped[old_id] = target['id']
            target['ljy_metadata'] = {k: v for k, v in n.items() if k not in ('id', 'file', 'type', 'parent')}
        else:
            node = dict(id='LJY:' + old_id, kind=kind, name=n.get('name') or canonical.rsplit('.', 1)[-1],
                        canonical_name=canonical, file=file, line=n.get('line'),
                        end_line=n.get('end_lineno'), producer='ljy')
            mapped[old_id] = node['id']
            extra_nodes.append(node)

    def remap(value):
        if isinstance(value, str):
            if value in mapped:
                return mapped[value]
            for prefix in ('package:', 'module:', 'class:', 'function:'):
                if value.startswith(prefix) and value[len(prefix):] in mapped:
                    return prefix + mapped[value[len(prefix):]]
            return value
        if isinstance(value, list):
            return [remap(x) for x in value]
        if isinstance(value, dict):
            return {k: (repository + '/' + v if k == 'file' and isinstance(v, str) else remap(v))
                    for k, v in value.items()}
        return value

    existing = {(e['source'], e['target'], e['type'], e.get('evidence', {}).get('line'))
                for e in [*graph['edges'], *graph.get('implicit_edges', [])]}
    types = {'calls': 'CALLS', 'calls_override': 'CALLS_OVERRIDE',
             'calls_implicit': 'CALLS_IMPLICIT', 'references': 'REFERENCES', 'imports': 'IMPORTS'}
    supplemental, skipped = [], Counter()
    resolved_lines = {(e['source'], e.get('evidence', {}).get('line')) for e in graph['edges']
                      if e['type'] in ('CALLS', 'INSTANTIATES')}
    supported_vias = {'type_hint', 'container_elem', 'local_assign', 'self_attr', 'return_type'}
    for e in native['edges']:
        if e['type'] not in types:
            continue
        source, target = mapped[e['from']], mapped[e['to']]
        kind = types[e['type']]
        target_node = nodes.get(target)
        if kind.startswith('CALLS'):
            # Legacy heuristic edges cannot undo the primary engine's proven
            # namespace/decorator barriers or silently select duplicate defs.
            if not target_node or target not in resolver.by_id:
                skipped['unmatched_callable'] += 1
                continue
            if not resolver.safe_callable(resolver.by_id[target]):
                skipped['unsafe_callable'] += 1
                continue
            if target_node['kind'] == 'CLASS':
                kind = 'INSTANTIATES'
        key = (source, target, kind, e.get('line'))
        if key in existing:
            continue
        existing.add(key)
        eligible = ((kind == 'CALLS' and e.get('via') in supported_vias
                     and (source, e.get('line')) not in resolved_lines)
                    or kind == 'CALLS_IMPLICIT')
        supplemental.append(dict(source=source, target=target, type=kind, evidence=dict(
            file=repository + '/' + native_nodes[e['from']]['file'], line=e.get('line'),
            producer='ljy', legacy_type=e['type'], legacy_via=e.get('via'),
            certainty='supplemental_may_call' if kind.startswith('CALLS') else 'static_reference',
            rule='ljy_' + e['type'],
            prediction_eligible=eligible,
            implicit_kind=e.get('via') if kind == 'CALLS_IMPLICIT' else None)))

    graph['schema_version'] = 2
    graph['analysis_profile'] = 'integrated'
    graph['call_graph_policy'] = call_policy
    graph['supplemental_nodes'] = extra_nodes
    graph['supplemental_edges'] = supplemental
    graph['supplemental_summary'] = dict(producer='ljy', edges=len(supplemental),
                                       types=dict(Counter(e['type'] for e in supplemental)),
                                       skipped=dict(skipped))
    for field in ('entry_points', 'reading_order', 'hierarchy', 'import_cycles', 'dynamic_calls'):
        graph[field] = remap(native[field])
    graph['ljy_result'] = native
    graph['integration_contract'] = dict(
        primary_call_statuses='Unchanged primary-engine explicit call sites',
        supplemental_edges='Additional static candidates; never counted as confirmed call sites',
        navigation_ids='Shared node IDs, plus supplemental_nodes for legacy-only scopes',
        native_export='ljy_graph.json uses the original file::qualified-name namespace')
    return graph


def selected_supplemental_edges(graph):
    policy = graph.get('call_graph_policy', 'primary')
    edges = graph.get('supplemental_edges', [])
    if policy == 'augmented':
        return edges
    if policy == 'supported':
        return [e for e in edges if e.get('evidence', {}).get('prediction_eligible')]
    return []


def write_legacy_outputs(graph, symbols, out):
    """Expose all original graph/navigation features through the preserved viewer."""
    import knit_viewer
    from symbol_builder import save_json
    native = graph.get('ljy_result')
    if native is None:
        return
    out = Path(out)
    save_json(native, out / 'ljy_graph.json')
    data = knit_viewer.slim(native, with_source=False, project=symbols.get('repository'))
    sources = symbols.get('analysis_sources') or {}
    repository = symbols.get('repository')
    data['source'] = {}
    for n in native['nodes']:
        text = sources.get(repository + '/' + n.get('file', ''))
        if text and n['type'] in ('class', 'function', 'method'):
            lines = text.splitlines()
            start = max(0, n['line'] - 1)
            data['source'][n['id']] = '\n'.join(lines[start:min(n.get('end_lineno') or n['line'], start+40)])
    (out / 'ljy_report.html').write_text(knit_viewer.build_html(data), encoding='utf-8')
