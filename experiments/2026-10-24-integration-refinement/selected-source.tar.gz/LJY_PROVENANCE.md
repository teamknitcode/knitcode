# 이정연 분석기 원본 보존

`knit_viewer.py`, `viewer_template.html`, `compare_pycg.py`는 Lee-jeongyeon/KnitCode의 main `d3a9da6`에서 변경 없이 가져왔다. 원본 API·JSON·오프라인 뷰어를 보존한다. 원본 `trace_recall.py`도 변경 없이 보존하되 현재 추적 도구와 충돌하지 않도록 파일 이름은 `ljy_trace_recall.py`로 정했다.

`tests/ljy_original`의 원본 테스트는 저장 위치에 맞춰 ROOT 경로를 조정하고 위 추적 도구의 import·CLI 경로만 새 이름으로 변경했다. 호출 정답은 변경하지 않았다. `tests/jse_original`은 정세은 기반 원본 테스트를 보존하며, 재배치된 CLI 경로와 fixture 수집 제외만 조정했다.

새 통합 어댑터는 `ljy_integration.py`다. 기존 모듈형 엔진의 호출 상태와 이정연의 보충 후보를 구분한다. 기본 `supported` 정책은 기존 해석을 유지하고 타입 추적 근거가 있는 미해결 호출만 예측에 추가한다. 전체 원본 결과·다형성 후보·참조·탐색 메타데이터는 별도로 유지한다.


2026-10-25 최적화에서 `analyze_project.py`에는 기존 독립 실행 API를 유지하면서 사전 파싱 AST·스냅샷 기반 import/console-script 메타데이터를 받을 수 있는 선택적 입력을 추가했다. 원본 의미 분석을 임시 파일로 재구성하지 않고 공유 AST에서 실행하기 위한 변경이다. 원본 상태는 이전 실험 소스 압축본에 보존했고, 디스크 분석·스냅샷·JSON fallback의 결과 동일성을 회귀 검사로 확인했다.

기본 `supported` 정책은 이제 선언된 부모 타입 매개변수에 한해 C3 계층으로 증명되는 자식 후보도 선택한다. 구체 객체의 임의 자식 확장은 계속 제외한다.
