"""Selection and refinements: experiments/2026-10-24-integration-refinement/."""
DEFAULT_PROFILE = 'integrated'
DEFAULT_CALL_POLICY = 'supported'
