"""Repository-wide, no-execution AST facts for the KnitCode v1 analyzer."""
from __future__ import annotations
import ast
import re
import tokenize
from pathlib import Path
from typing import Any

SKIP_DIRS = {'.git', '.venv', 'venv', '__pycache__', 'node_modules', 'build', 'dist', '.tox', '.mypy_cache', '.pytest_cache', 'output'}


def loc(node: ast.AST) -> dict[str, Any]:
    return {k: getattr(node, v, None) for k, v in (("line", "lineno"), ("column", "col_offset"), ("end_line", "end_lineno"), ("end_column", "end_col_offset"))}


# Same line splitting as ast.get_source_segment: \r\n, \r, \n only (no \f).
_LINE = re.compile(r'.*?(?:\r\n|\r|\n)|.+', re.S)


class SourceText:
    """Source string with its line list computed once.

    ast.get_source_segment re-splits the whole file on every call, which was
    quadratic for large modules. Columns are UTF-8 byte offsets, as in ast.
    """
    def __init__(self, source: str):
        self.source = source
        self.lines = _LINE.findall(source)

    def segment(self, node: ast.AST) -> str | None:
        try:
            if node.end_lineno is None or node.end_col_offset is None:
                return None
            first, last = node.lineno - 1, node.end_lineno - 1
            start, end = node.col_offset, node.end_col_offset
        except AttributeError:
            return None
        lines = self.lines
        if first == last:
            return lines[first].encode()[start:end].decode()
        return ''.join([lines[first].encode()[start:].decode(), *lines[first + 1:last],
                        lines[last].encode()[:end].decode()])


def text_of(source: str | SourceText, node: ast.AST | None) -> str | None:
    if node is None:
        return None
    if isinstance(source, SourceText):
        return source.segment(node)
    return ast.get_source_segment(source, node)


def expr_name(node: ast.AST | None) -> str | None:
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        base = expr_name(node.value)
        return f"{base}.{node.attr}" if base else None
    if isinstance(node, ast.Call):
        base = expr_name(node.func)
        return f"{base}()" if base else None
    if isinstance(node, ast.Subscript):
        return expr_name(node.value)
    return None


def binding_of(node: ast.AST | None) -> dict[str, Any]:
    if isinstance(node, ast.Call):
        name = expr_name(node.func)
        return {"kind": "call", "callee": name} if name else {"kind": "unknown"}
    if isinstance(node, ast.Name):
        return {"kind": "name", "name": node.id}
    if isinstance(node, ast.Attribute):
        return {"kind": "attribute", "name": expr_name(node)}
    if isinstance(node, (ast.List, ast.Tuple, ast.Set)):
        names = [expr_name(x) for x in node.elts]
        if all(names):
            return {"kind": "sequence", "items": names}
    return {"kind": "unknown"}


class FactsVisitor(ast.NodeVisitor):
    def __init__(self, source: str):
        self.source = SourceText(source)
        self.scopes: list[str] = []
        self.scope_types: list[str] = []
        # Lexical scope and executing caller are different for definitions,
        # class bodies, and deferred lambda bodies.
        self.execution_owners: list[str] = ['<module>']
        self.execution_phases: list[str] = ['module_initialization']
        self.control_depth = 0
        self.classes: list[dict] = []
        self.functions: list[dict] = []
        self.imports: list[dict] = []
        self.calls: list[dict] = []
        self.assignments: list[dict] = []
        self.binding_hazards: list[dict] = []  # v2.3.1: lexically risky rebinding only

    @property
    def scope(self) -> str:
        return '.'.join(self.scopes) or '<module>'

    def _visit_with_phase(self, nodes, phase: str) -> None:
        self.execution_phases.append(phase)
        try:
            for node in nodes:
                if node is not None:
                    self.visit(node)
        finally:
            self.execution_phases.pop()

    def _visit_function_definition(self, node: ast.FunctionDef | ast.AsyncFunctionDef, kind: str) -> None:
        # Decorators, defaults, and (eager) annotations are evaluated when
        # the *enclosing* context executes the definition, not in the body.
        qname = '.'.join([*self.scopes, node.name])
        args = (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs)
        self.functions.append({
            'name': node.name, 'qualified_name': qname,
            'scope': self.scope, 'control_depth': self.control_depth,
            'decorators': [text_of(self.source, x) for x in node.decorator_list],
            'kind': kind, 'async': isinstance(node, ast.AsyncFunctionDef),
            'parameters': [x.arg for x in args],
            'parameter_annotations': {x.arg: text_of(self.source, x.annotation)
                                      for x in args if x.annotation is not None},
            'return_annotation': text_of(self.source, node.returns),
            **loc(node),
        })
        self._visit_with_phase(node.decorator_list, 'definition_decorator')
        self._visit_with_phase([*node.args.defaults, *node.args.kw_defaults], 'definition_default')
        # Python 3.13 may evaluate annotations eagerly; future annotations
        # and Python 3.14+ differ. Preserve these call sites with an explicit
        # version-sensitive execution phase rather than dropping evidence.
        annotations = [arg.annotation for arg in args]
        annotations.extend([node.args.vararg.annotation] if node.args.vararg else [])
        annotations.extend([node.args.kwarg.annotation] if node.args.kwarg else [])
        annotations.append(node.returns)
        self._visit_with_phase(annotations, 'definition_annotation')
        self.scopes.append(node.name)
        self.scope_types.append(kind)
        self.execution_owners.append(qname)
        self.execution_phases.append('function_body')
        try:
            for stmt in node.body:
                self.visit(stmt)
        finally:
            self.execution_phases.pop()
            self.execution_owners.pop()
            self.scope_types.pop()
            self.scopes.pop()

    def visit_ClassDef(self, node: ast.ClassDef):
        qname = '.'.join([*self.scopes, node.name])
        self.classes.append({
            'name': node.name, 'qualified_name': qname,
            'scope': self.scope, 'control_depth': self.control_depth,
            'decorators': [text_of(self.source, x) for x in node.decorator_list],
            'bases': [text_of(self.source, x) for x in node.bases],
            'class_keywords': [kw.arg for kw in node.keywords],
            'class_keyword_values': {kw.arg: text_of(self.source, kw.value)
                                     for kw in node.keywords if kw.arg},
            **loc(node),
        })
        self._visit_with_phase(node.decorator_list, 'class_decorator')
        self._visit_with_phase([*node.bases, *(kw.value for kw in node.keywords)], 'class_header')
        # Executing a class body does not execute an instance method. Its
        # caller is whoever executes the class definition (often the module).
        self.scopes.append(node.name)
        self.scope_types.append('CLASS')
        self.execution_phases.append('class_body')
        try:
            for stmt in node.body:
                self.visit(stmt)
        finally:
            self.execution_phases.pop()
            self.scope_types.pop()
            self.scopes.pop()

    def visit_FunctionDef(self, node: ast.FunctionDef):
        kind = 'METHOD' if self.scope_types and self.scope_types[-1] == 'CLASS' else 'FUNCTION'
        self._visit_function_definition(node, kind)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef):
        kind = 'METHOD' if self.scope_types and self.scope_types[-1] == 'CLASS' else 'FUNCTION'
        self._visit_function_definition(node, kind)

    def visit_Lambda(self, node: ast.Lambda):
        # Evaluating a lambda creates a function object; its body runs later.
        self._visit_with_phase([*node.args.defaults, *node.args.kw_defaults], 'lambda_default')
        name = f'<lambda@{node.lineno}:{node.col_offset}>'
        qname = '.'.join([*self.scopes, name])
        params = (*node.args.posonlyargs, *node.args.args, *node.args.kwonlyargs)
        self.functions.append({
            'name': name, 'qualified_name': qname, 'scope': self.scope,
            'control_depth': self.control_depth, 'decorators': [],
            'kind': 'LAMBDA', 'async': False,
            'parameters': [arg.arg for arg in params],
            'parameter_annotations': {}, 'return_annotation': None,
            **loc(node),
        })
        self.scopes.append(name)
        self.scope_types.append('LAMBDA')
        self.execution_owners.append(qname)
        self.execution_phases.append('lambda_body')
        try:
            self.visit(node.body)
        finally:
            self.execution_phases.pop()
            self.execution_owners.pop()
            self.scope_types.pop()
            self.scopes.pop()

    def visit_Import(self, node: ast.Import):
        for alias in node.names:
            self.imports.append({"type": "IMPORT", "module": alias.name, "name": None,
                                 "alias": alias.asname, "level": 0, "scope": self.scope,
                                 "control_depth": self.control_depth, **loc(node)})

    def visit_ImportFrom(self, node: ast.ImportFrom):
        for alias in node.names:
            self.imports.append({"type": "IMPORT_FROM", "module": node.module, "name": alias.name,
                                 "alias": alias.asname, "level": node.level, "scope": self.scope,
                                 "control_depth": self.control_depth, **loc(node)})

    def visit_Call(self, node: ast.Call):
        name = expr_name(node.func)
        self.calls.append({"callee_text": name or text_of(self.source, node.func),
                           "syntax_type": 'NAME' if isinstance(node.func, ast.Name) else 'ATTRIBUTE' if isinstance(node.func, ast.Attribute) else 'COMPLEX',
                           "scope": self.scope,
                           "execution_scope": self.execution_owners[-1],
                           "execution_phase": self.execution_phases[-1],
                           "positional_argument_count": len(node.args),
                           "keyword_arguments": [kw.arg for kw in node.keywords],
                           "source": text_of(self.source, node), **loc(node)})
        self.generic_visit(node)

    def _assignment(self, node: ast.AST, targets: list[ast.AST], value: ast.AST | None, typ: str):
        names = [expr_name(x) for x in targets]
        self.assignments.append({"type": typ, "targets": [x for x in names if x],
                                 "value": text_of(self.source, value), "scope": self.scope,
                                 "binding": binding_of(value), "control_depth": self.control_depth,
                                 **loc(node)})

    def visit_Assign(self, node: ast.Assign):
        targets = []
        for target in node.targets:
            if isinstance(target, (ast.Tuple, ast.List)):
                targets.extend(target.elts)
            else:
                targets.append(target)
        self._assignment(node, targets, node.value, 'ASSIGN')
        self.generic_visit(node)

    def visit_AnnAssign(self, node: ast.AnnAssign):
        self._assignment(node, [node.target], node.value, 'ANN_ASSIGN')
        self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign):
        self._assignment(node, [node.target], None, 'AUG_ASSIGN')
        self.generic_visit(node)

    def visit_For(self, node: ast.For):
        self._visit_for(node)

    def visit_AsyncFor(self, node: ast.AsyncFor):
        self._visit_for(node)

    def _visit_for(self, node: ast.For | ast.AsyncFor):
        names = list(node.target.elts) if isinstance(node.target, (ast.Tuple, ast.List)) else [node.target]
        self.assignments.append({"type": "FOR_TARGET", "targets": [n for n in (expr_name(x) for x in names) if n],
                                 "value": text_of(self.source, node.iter), "scope": self.scope,
                                 "binding": {"kind": "iterate", "source": expr_name(node.iter)},
                                 "control_depth": self.control_depth, **loc(node.target)})
        self.visit(node.iter)
        self.control_depth += 1
        for child in (*node.body, *node.orelse):
            self.visit(child)
        self.control_depth -= 1

    def visit_If(self, node: ast.If):
        self.visit(node.test)
        self.control_depth += 1
        for child in (*node.body, *node.orelse):
            self.visit(child)
        self.control_depth -= 1

    def visit_While(self, node: ast.While):
        self.visit(node.test)
        self.control_depth += 1
        for child in (*node.body, *node.orelse):
            self.visit(child)
        self.control_depth -= 1

    def visit_Match(self, node: ast.Match):
        self.visit(node.subject)
        self.control_depth += 1
        for case in node.cases:
            for pattern in ast.walk(case.pattern):
                if isinstance(pattern, (ast.MatchAs, ast.MatchStar)):
                    self._hazard(pattern, pattern.name, 'MATCH_CAPTURE')
                elif isinstance(pattern, ast.MatchMapping):
                    self._hazard(pattern, pattern.rest, 'MATCH_CAPTURE')
            self.visit(case.pattern)
            if case.guard is not None:
                self.visit(case.guard)
            for child in case.body:
                self.visit(child)
        self.control_depth -= 1

    def _hazard(self, node, name, typ):
        if name:
            self.binding_hazards.append({"name": name, "type": typ,
                                         "scope": self.scope,
                                         "control_depth": self.control_depth, **loc(node)})

    def visit_Global(self, node: ast.Global):
        for name in node.names:
            self._hazard(node, name, 'GLOBAL')

    def visit_Nonlocal(self, node: ast.Nonlocal):
        for name in node.names:
            self._hazard(node, name, 'NONLOCAL')

    def visit_Delete(self, node: ast.Delete):
        for target in node.targets:
            self._hazard(node, expr_name(target), 'DELETE')
        self.generic_visit(node)

    def visit_NamedExpr(self, node: ast.NamedExpr):
        self._hazard(node, expr_name(node.target), 'WALRUS')
        self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler):
        self._hazard(node, node.name, 'EXCEPT_ALIAS')
        self.generic_visit(node)

    def visit_With(self, node: ast.With):
        for item in node.items:
            self._hazard(node, expr_name(item.optional_vars), 'WITH_ALIAS')
        self.generic_visit(node)

    def visit_AsyncWith(self, node: ast.AsyncWith):
        for item in node.items:
            self._hazard(node, expr_name(item.optional_vars), 'WITH_ALIAS')
        self.generic_visit(node)

    def visit_Try(self, node: ast.Try):
        self.control_depth += 1
        self.generic_visit(node)
        self.control_depth -= 1


def detect_source_roots(root: Path) -> list[str]:
    """Recognize unambiguous conventional ``src/<package>`` layouts.

    Do not interpret an actual ``src`` Python package as an import root, and
    do not merge two packages with the same name across different roots.
    Explicit --source-root overrides this conservative heuristic.
    """
    src = root / 'src'
    if not src.is_dir() or (src / '__init__.py').exists():
        return []
    packages = [p.name for p in src.iterdir()
                if p.is_dir() and p.name.isidentifier() and (p / '__init__.py').is_file()]
    if not packages or any((root / name).exists() for name in packages):
        return []
    return ['src']


def scan_repository(root: str | Path, *, source_roots: list[str] | None = None) -> dict[str, Any]:
    root = Path(root).resolve()
    if not root.is_dir():
        raise FileNotFoundError(f"Repository folder not found: {root}")
    if source_roots is None:
        source_roots = detect_source_roots(root)
    else:
        validated = []
        for entry in source_roots:
            rel = Path(entry)
            if rel.is_absolute() or '..' in rel.parts or not (root / rel).is_dir():
                raise ValueError(f'Invalid source root: {entry!r}')
            normalized = rel.as_posix().strip('./')
            if normalized:
                validated.append(normalized)
        source_roots = sorted(set(validated), key=len, reverse=True)
    files: list[dict] = []
    errors: list[dict] = []
    for file in sorted(root.rglob('*.py')):
        if any(p in SKIP_DIRS for p in file.relative_to(root).parts[:-1]):
            continue
        relative = f"{root.name}/{file.relative_to(root).as_posix()}"
        try:
            # Python source may declare a PEP 263 encoding or carry a UTF-8 BOM.
            with tokenize.open(file) as stream:
                source = stream.read()
            tree = ast.parse(source, filename=str(file))
            visitor = FactsVisitor(source)
            visitor.visit(tree)
            # Optional facts: snapshot abstract variable values at each call
            # without executing any code from the target repository.
            from flow_analysis import FlowAnalyzer
            flow = FlowAnalyzer().analyze(tree)
            for call in visitor.calls:
                snap = flow.get((call.get('line'), call.get('column')))
                if snap is not None:
                    call['flow'] = snap
            files.append({"file": relative, "source": source, "classes": visitor.classes, "functions": visitor.functions,
                          "imports": visitor.imports, "calls": visitor.calls, "assignments": visitor.assignments,
                          "binding_hazards": visitor.binding_hazards})
        except (SyntaxError, UnicodeError, OSError) as exc:
            errors.append({"file": relative, "type": type(exc).__name__, "message": str(exc)})
    return {"repository": root.name, "root": str(root), "source_roots": source_roots,
            "python_file_count": len(files),
            "parse_errors": errors, "files": files}
