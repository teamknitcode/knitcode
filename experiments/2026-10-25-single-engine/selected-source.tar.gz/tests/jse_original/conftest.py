collect_ignore = ["fixtures"]
